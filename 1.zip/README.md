# Hashtags (Projeto 2)

**Membros do Grupo:**
- Gonçalo Marques (84719)
- Manuel Sousa (84740)

**Linguagem do Projeto:** C (gcc) <br/>

**Cadeira:** Introdução aos Algoritmos e Estruturas de Dados 

Para Compilar:
==========

```
    cd /codigo_fonte/
    make clean
    make all
    make run
```

Código Fonte:
==========
+ main.c
-> 
